"""Shared support for the non-synthesizable @sim_input/@sim_output
testbenches (plain Python data/helpers, no hardware).

KEY/NONCE/AAD match tb_common.py's synthesizable-style vectors (duplicated
here rather than cross-imported, so the two testbench styles stay fully
decoupled). Unlike tb_common.py, this module does not precompute any
ciphertext/tag vectors -- encrypt_tb.py/decrypt_tb.py call
aead_ref_model.generate_encrypt_vector(...) lazily, once per randomly
generated packet, during live simulation.
"""

import random

from pypeline import param


# Converged-handshake AXIS source/sink (present in @sim_input, commit on the
# converged ready in @sim_output) live in PipelineC's axi/axis_sim.py; the
# WireGuard testbenches keep their original names.
from axi.axis_sim import (
    ConvergedAxisSimSink as ConvergedAxisSink,
    ConvergedAxisSimSource as ConvergedAxisSource,
)


# Optional native functional stress (-D TB_STRESS=1). Performance testbenches
# never use these pauses: their sinks remain always ready and their sources
# always offer work.
STRESS = param("TB_STRESS", False, help="random testbenches: 16 directed packets, input gaps and output backpressure")


def input_paused(direction, cycle):
    offset = 0 if direction == "encrypt" else 9
    return STRESS and (cycle + offset) % 37 < 6


def output_ready(direction, cycle):
    if not STRESS:
        return 1
    offset = 0 if direction == "encrypt" else 173
    slot = (cycle + offset) % 1100
    return int(not (200 <= slot < 500 or slot % 23 < 5))


# Test vectors (same fixed values as tb_common.py)
KEY = list(range(0x80, 0xA0))  # 0x80, 0x81, ... 0x9f

NONCE = [0x07, 0x00, 0x00, 0x00, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47]

AAD_TEST_STR = "Additional authenticated data"
AAD_MAX_LEN = 32
AAD_LEN = len(AAD_TEST_STR)  # 29
AAD = list(AAD_TEST_STR.encode()) + [0] * (AAD_MAX_LEN - AAD_LEN)

# Random packet generation
NUM_RANDOM_PACKETS = 16 if STRESS else 12
PACKET_LEN_MIN = 1
PACKET_LEN_MAX = 1024

# The first len(CORNER_CASE_LENS) packets each run are pinned to these
# lengths -- the same corner cases tb_common.py's PLAINTEXT_TEST_STRS
# comment covers (15/31 pin r=15, see there and README's "Xilinx-style
# tkeep" section): 16 is exactly one word, 17 is one word plus one byte, 64
# is exactly one ChaCha20 block, 128 is the old fixed-vector max. Remaining
# packets are uniform-random over [PACKET_LEN_MIN, PACKET_LEN_MAX].
CORNER_CASE_LENS = [15, 16, 17, 31, 64, 128]
if STRESS:
    CORNER_CASE_LENS = [15, 16, 17, 31, 63, 64, 65, 128, 511, 512, 513,
                        1024, 1420, 1920, 1920, 1920]

# Fixed default seed (nod to RFC 8439) so a failing run's exact vectors are
# reproducible by re-seeding with the same value; the seed actually used is
# always printed via sim_print at the start of each run.
DEFAULT_SEED = 8439


def next_packet_length(rng: random.Random, packet_idx: int) -> int:
    """Length in bytes for random packet `packet_idx` (0-based) of a run.

    The first few packets are pinned to CORNER_CASE_LENS (guaranteed
    coverage every run); the rest are uniform-random.
    """
    if packet_idx < len(CORNER_CASE_LENS):
        return CORNER_CASE_LENS[packet_idx]
    return rng.randint(PACKET_LEN_MIN, PACKET_LEN_MAX)
