//////////////////////////////////////////////////////////////////////////////////
//   vga color bar test                                                         //
//                                                                              //
//  Author: meisq                                                               //
//          msq@qq.com                                                          //
//          ALINX(shanghai) Technology Co.,Ltd                                  //
//          heijin                                                              //
//     WEB: http://www.alinx.cn/                                                //
//     BBS: http://www.heijin.org/                                              //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// Copyright (c) 2017,ALINX(shanghai) Technology Co.,Ltd                        //
//                    All rights reserved                                       //
//                                                                              //
// This source file may be used and distributed without restriction provided    //
// that this copyright statement is not removed from the file and that any      //
// derivative work contains the original copyright notice and the associated    //
// disclaimer.                                                                  //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

//================================================================================
//  Revision History:
//  Date          By            Revision    Change Description
//--------------------------------------------------------------------------------
//2017/7/20                    1.0          Original
//*******************************************************************************/
module top(
input                       sys_clk_p,          //system clock positive
input                       sys_clk_n,          //system clock negative 
input                       rst_n,              //reset ,low active
output                      vga_out_hs,         //vga horizontal synchronization
output                      vga_out_vs,         //vga vertical synchronization
output[4:0]                 vga_out_r,          //vga red
output[5:0]                 vga_out_g,          //vga green
output[4:0]                 vga_out_b           //vga blue
);
wire                       video_clk;           //pixel clock
wire                       video_hs;            //horizontal synchronization
wire                       video_vs;            //vertical synchronization
wire                       video_de;            //video valid
wire[7:0]                  video_r;             //video red data
wire[7:0]                  video_g;             //video green data
wire[7:0]                  video_b;             //video blue data
wire                       sys_clk;             //single end clock   

wire                       osd_hs;           //osd horizontal synchronization
wire                       osd_vs;           //osd vertical synchronization
wire                       osd_de;           //osd data valid
wire[7:0]                  osd_r;            //osd red data
wire[7:0]                  osd_g;            // osd green data
wire[7:0]                  osd_b;            //osd blue
assign vga_out_hs           = osd_hs;
assign vga_out_vs           = osd_vs;
assign vga_out_r            = osd_r[7:3];
assign vga_out_g            = osd_g[7:2];
assign vga_out_b            = osd_b[7:3];
/*************************************************************************
generate single end clock
**************************************************************************/
IBUFDS sys_clk_ibufgds
(
.O                          (sys_clk                  ),
.I                          (sys_clk_p                ),
.IB                         (sys_clk_n                )
);
/*************************************************************************
Generate the pixel clock required for the video
****************************************************************************/
video_pll video_pll_m0
(
.clk_in1                    (sys_clk                  ),
.clk_out1                   (video_clk                ),
.reset                      (1'b0                     ),
.locked                     (                         )
);
/*************************************************************************
Call color bar generation module
****************************************************************************/
color_bar color_bar_m0(
.clk                        (video_clk                ),
.rst                        (~rst_n                   ),
.hs                         (video_hs                 ),
.vs                         (video_vs                 ),
.de                         (video_de                 ),
.rgb_r                      (video_r                  ),
.rgb_g                      (video_g                  ),
.rgb_b                      (video_b                  )
);
/*************************************************************************
Character OSD display
****************************************************************************/
osd_display  osd_display_m0
(
.rst_n                      (rst_n                    ),
.pclk                       (video_clk                ),
.i_hs                       (video_hs                 ),
.i_vs                       (video_vs                 ),
.i_de                       (video_de                 ),
.i_data                     ({video_r,video_g,video_b}),
.o_hs                       (osd_hs                   ),
.o_vs                       (osd_vs                   ),
.o_de                       (osd_de                   ),
.o_data                     ({osd_r,osd_g,osd_b}      )
);
endmodule