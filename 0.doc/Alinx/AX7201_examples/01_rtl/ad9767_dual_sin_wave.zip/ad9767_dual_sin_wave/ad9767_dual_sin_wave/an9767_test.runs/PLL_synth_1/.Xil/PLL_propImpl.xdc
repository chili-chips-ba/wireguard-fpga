set_property SRC_FILE_INFO {cfile:/home/extern_disk/meisq/ax7201/ad9767_dual_sin_wave/ad9767_dual_sin_wave/an9767_test.srcs/sources_1/ip/PLL/PLL.xdc rfile:../../../an9767_test.srcs/sources_1/ip/PLL/PLL.xdc id:1 order:EARLY scoped_inst:inst} [current_design]
current_instance inst
set_property src_info {type:SCOPED_XDC file:1 line:57 export:INPUT save:INPUT read:READ} [current_design]
set_input_jitter [get_clocks -of_objects [get_ports clk_in1]] 0.05
