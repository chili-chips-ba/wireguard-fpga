//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//                                                                              //
//  Author: meisq                                                               //
//          msq@qq.com                                                          //
//          ALINX(shanghai) Technology Co.,Ltd                                  //
//          heijin                                                              //
//     WEB: http://www.alinx.cn/                                                //
//     BBS: http://www.heijin.org/                                              //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// Copyright (c) 2017,ALINX(shanghai) Technology Co.,Ltd                        //
//                    All rights reserved                                       //
//                                                                              //
// This source file may be used and distributed without restriction provided    //
// that this copyright statement is not removed from the file and that any      //
// derivative work contains the original copyright notice and the associated    //
// disclaimer.                                                                  //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

//================================================================================
//  Revision History:
//  Date          By            Revision    Change Description
//--------------------------------------------------------------------------------
//2019/09/27                    1.0          Original
//*******************************************************************************/
module top
(
input                            sys_clk_p,               //system clock positive
input                            sys_clk_n,               //system clock negative 
input                            rst_n,                   //reset ,low active
input[7:0]                       ad9280_data,             //AD data         
output                           ad9280_clk,              //AD sampling clock
output[7:0]                      ad9708_data,             //DA data 
output                           ad9708_clk,              //DA clock
//vga output
output                           vga_out_hs,              //vga horizontal synchronization
output                           vga_out_vs,              //vga vertical synchronization
output[4:0]                      vga_out_r,               //vga red
output[5:0]                      vga_out_g,               //vga green
output[4:0]                      vga_out_b                //vga blue
);
wire                            video_clk;               //pixel clock
wire                            video_hs;                //horizontal synchronization
wire                            video_vs;                //vertical synchronization
wire                            video_de;                //video valid
wire[7:0]                       video_r;                 //video red data
wire[7:0]                       video_g;                 //video green data
wire[7:0]                       video_b;                 //video blue data

wire                            grid_hs;                 //grid horizontal synchronization
wire                            grid_vs;                 //grid vertical synchronization
wire                            grid_de;                 //grid data valid
wire[7:0]                       grid_r;                  //grid red data
wire[7:0]                       grid_g;                  //grid green data
wire[7:0]                       grid_b;                  //grid blue data

wire                            wave0_hs;                //wave 0 horizontal synchronization            
wire                            wave0_vs;                //wave 0 vertical synchronization
wire                            wave0_de;                //wave 0 data valid
wire[7:0]                       wave0_r;                 //wave 0 red data
wire[7:0]                       wave0_g;                 //wave 0 green data
wire[7:0]                       wave0_b;                 //wave 0 blue data

wire                            adc_clk;                 //ADC data processing clock
wire                            adc0_buf_wr;             //ADC channel 0 write buf enable
wire[10:0]                      adc0_buf_addr;           //ADC channel 0 write buf address
wire[7:0]                       adc0_buf_data;           //ADC channel 0 buf data
wire                            dac_clk;                 //DA clock:AD9708 clock 
wire[7:0]                       dac_data;                //DA data
reg[8:0]                        rom_addr;                //rom address
wire                            sys_clk;                 //single end clock 
assign vga_out_hs                = wave0_hs;
assign vga_out_vs                = wave0_vs;
assign vga_out_r                 = wave0_r[7:3]; 
assign vga_out_g                 = wave0_g[7:2]; 
assign vga_out_b                 = wave0_b[7:3]; 

assign ad9280_clk                = adc_clk;
assign ad9708_clk                = dac_clk;
assign ad9708_data               = dac_data;
/*************************************************************************
generate single end clock
**************************************************************************/
IBUFDS sys_clk_ibufgds
(
.O                              (sys_clk                 ),
.I                              (sys_clk_p               ),
.IB                             (sys_clk_n               )
);
/*************************************************************************
Generate the pixel clock  clock required for the video
****************************************************************************/
video_pll video_pll_m0
(
.clk_in1                        (sys_clk                  ),
.clk_out1                       (video_clk                ),
.reset                          (1'b0                     ),
.locked                         (                         )
);
/*************************************************************************
Generate the  clock required for the AD9280 �� AD9708 and ad data processing
****************************************************************************/
adda_pll adda_pll_m0
(
.clk_in1                        (sys_clk                  ),
.clk_out1                       (adc_clk                  ),
.clk_out2                       (dac_clk                  ),
.reset                          (1'b0                     ),
.locked                         (                         )   
);
 /*************************************************************************
Generate  a sine signal with a frequency of 244.14 kHz for DA
****************************************************************************/
always@(posedge dac_clk)
begin
	rom_addr <= rom_addr + 9'd1;
end
da_rom da_rom_m0 
(
.clka                           (dac_clk                  ),  
.ena                            (1'b1                     ),     
.addra                          (rom_addr                 ), 
.douta                          (dac_data                 )  
);
/*************************************************************************
Call color bar generation module
****************************************************************************/
color_bar color_bar_m0
(
.clk                            (video_clk                ),
.rst                            (~rst_n                   ),
.hs                             (video_hs                 ),
.vs                             (video_vs                 ),
.de                             (video_de                 ),
.rgb_r                          (video_r                  ),
.rgb_g                          (video_g                  ),
.rgb_b                          (video_b                  )
);
 /*************************************************************************
Grid image display
****************************************************************************/
grid_display  grid_display_m0
(
.rst_n                          (rst_n                    ),
.pclk                           (video_clk                ),
.i_hs                           (video_hs                 ),
.i_vs                           (video_vs                 ),
.i_de                           (video_de                 ),
.i_data                         ({video_r,video_g,video_b}),
.o_hs                           (grid_hs                  ),
.o_vs                           (grid_vs                  ),
.o_de                           (grid_de                  ),
.o_data                         ({grid_r,grid_g,grid_b}   )
);
/*************************************************************************
AD data pre-processing and interface signals for generating and storing data to RAM 
****************************************************************************/
ad9280_sample ad9280_sample_m0
(
.adc_clk                        (adc_clk                  ),
.rst                            (~rst_n                   ),
.adc_data                       (ad9280_data              ),
.adc_data_valid                 (1'b1                     ),
.adc_buf_wr                     (adc0_buf_wr              ),
.adc_buf_addr                   (adc0_buf_addr            ),
.adc_buf_data                   (adc0_buf_data            )
);
 /*************************************************************************
AD data and grid overlay
****************************************************************************/
wav_display wav_display_m0
(
.rst_n                          (rst_n                    ),
.pclk                           (video_clk                ),
.wave_color                     (24'hff0000               ),
.adc_clk                        (adc_clk                  ),
.adc_buf_wr                     (adc0_buf_wr              ),
.adc_buf_addr                   (adc0_buf_addr            ),
.adc_buf_data                   (adc0_buf_data            ),
.i_hs                           (grid_hs                  ),
.i_vs                           (grid_vs                  ),
.i_de                           (grid_de                  ),
.i_data                         ({grid_r,grid_g,grid_b}   ),
.o_hs                           (wave0_hs                 ),
.o_vs                           (wave0_vs                 ),
.o_de                           (wave0_de                 ),
.o_data                         ({wave0_r,wave0_g,wave0_b})
);
endmodule