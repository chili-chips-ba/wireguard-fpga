set_property SRC_FILE_INFO {cfile:/home/extern_disk/meisq/ax7201/gtp_test/gtp_1g_test/gtp_1g_test.srcs/sources_1/ip/sys_clock/sys_clock.xdc rfile:../../../gtp_1g_test.srcs/sources_1/ip/sys_clock/sys_clock.xdc id:1 order:EARLY scoped_inst:inst} [current_design]
current_instance inst
set_property src_info {type:SCOPED_XDC file:1 line:57 export:INPUT save:INPUT read:READ} [current_design]
set_input_jitter [get_clocks -of_objects [get_ports clk_in1]] 0.05
