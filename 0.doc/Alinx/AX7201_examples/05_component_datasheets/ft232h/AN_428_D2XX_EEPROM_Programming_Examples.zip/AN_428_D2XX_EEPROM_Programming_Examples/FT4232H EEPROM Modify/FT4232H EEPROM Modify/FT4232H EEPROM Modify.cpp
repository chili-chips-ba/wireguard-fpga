// FT4232H EEPROM Modify.cpp : Defines the entry point for the console application.
//

// NOTE:	This code is provided as an example only and is not supported or guaranteed by FTDI.
//			It is the responsibility of the recipient/user to ensure the correct operation of 
//			any software which is created based upon this example.

#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include "ftd2xx.h"

int main()
{
	//********************************************************
	//Definitions
	//********************************************************

	FT_HANDLE fthandle;
	FT_STATUS status;
	
	BOOLEAN Dev_Found = FALSE;

	FT_PROGRAM_DATA ftData;

	WORD VendorIdBuf = 0x0403;
	WORD ProductIdBuf = 0x6011;
	char ManufacturerBuf[32];
	char ManufacturerIdBuf[16];
	char DescriptionBuf[64];
	char SerialNumberBuf[16];

	ftData.Signature1 = 0x00000000;		// Always 0x00000000
	ftData.Signature2 = 0xffffffff;		// Always 0xFFFFFFFF
	ftData.Version = 4;	// Header - FT_PROGRAM_DATA version 0 = original (FT232B), 1 = FT2232 extensions, 2 = FT232R extensions, 3 = FT2232H extensions, 4 = FT4232H extensions, 5 = FT232H extensions

	ftData.VendorId = VendorIdBuf;
	ftData.ProductId = ProductIdBuf;
	ftData.Manufacturer = ManufacturerBuf;
	ftData.ManufacturerId = ManufacturerIdBuf;
	ftData.Description = DescriptionBuf;
	ftData.SerialNumber = SerialNumberBuf;

	ftData.MaxPower;
	ftData.PnP;
	ftData.SelfPowered;
	ftData.RemoteWakeup;

	//'FT4232H features require section below
	ftData.PullDownEnable8;		// non-zero if pull down enabled
	ftData.SerNumEnable8;		// non-zero if serial number to be used
	ftData.ASlowSlew;			// non-zero if A pins have slow slew
	ftData.ASchmittInput;		// non-zero if A pins are Schmitt input
	ftData.ADriveCurrent;		// valid values are 4mA, 8mA, 12mA, 16mA
	ftData.BSlowSlew;			// non-zero if B pins have slow slew
	ftData.BSchmittInput;		// non-zero if B pins are Schmitt input
	ftData.BDriveCurrent;		// valid values are 4mA, 8mA, 12mA, 16mA
	ftData.CSlowSlew;			// non-zero if C pins have slow slew
	ftData.CSchmittInput;		// non-zero if C pins are Schmitt input
	ftData.CDriveCurrent;		// valid values are 4mA, 8mA, 12mA, 16mA
	ftData.DSlowSlew;			// non-zero if D pins have slow slew
	ftData.DSchmittInput;		// non-zero if D pins are Schmitt input
	ftData.DDriveCurrent;		// valid values are 4mA, 8mA, 12mA, 16mA
	ftData.ARIIsTXDEN;			// non-zero if port A uses RI as RS485 TXDEN
	ftData.BRIIsTXDEN;			// non-zero if port B uses RI as RS485 TXDEN
	ftData.CRIIsTXDEN;			// non-zero if port C uses RI as RS485 TXDEN
	ftData.DRIIsTXDEN;			// non-zero if port D uses RI as RS485 TXDEN
	ftData.AIsVCP8;				// non-zero if interface is to use VCP drivers
	ftData.BIsVCP8;				// non-zero if interface is to use VCP drivers
	ftData.CIsVCP8;				// non-zero if interface is to use VCP drivers
	ftData.DIsVCP8;				// non-zero if interface is to use VCP drivers

	//********************************************************
	//List Devices
	//********************************************************

	FT_DEVICE_LIST_INFO_NODE *devInfo;
	DWORD numDevs;
	DWORD i;

	// create the device information list 
	status = FT_CreateDeviceInfoList(&numDevs);

	if (status != FT_OK) {
		printf("FT_CreateDeviceInfoList status not ok %d\n", status);
		return 0;
	}
	else
	{
		printf("Number of devices is %d\n", numDevs);
		if (numDevs > 0) {
			// allocate storage for list based on numDevs 
			devInfo =
				(FT_DEVICE_LIST_INFO_NODE*)malloc(sizeof(FT_DEVICE_LIST_INFO_NODE)*numDevs);
			// get the device information list 
			status = FT_GetDeviceInfoList(devInfo, &numDevs);
			if (status == FT_OK) {
				for (i = 0; i < numDevs; i++) {
					printf("Dev %d:\n", i);
					printf("Flags=0x%x\n", devInfo[i].Flags);
					printf("Type=0x%x\n", devInfo[i].Type);
					printf("ID=0x%x\n", devInfo[i].ID);
					printf("LocId=0x%x\n", devInfo[i].LocId);
					printf("SerialNumber=%s\n", devInfo[i].SerialNumber);
					printf("Description=%s\n", devInfo[i].Description);
					printf("\n");
				}
			}
		}
	}

	//********************************************************
	//Open the port
	//********************************************************

	for (i = 0; i < numDevs; i++)
	{
		if ((Dev_Found == FALSE) && (devInfo[i].Type == FT_DEVICE_4232H))
		{
			Dev_Found = TRUE;
			
			status = FT_OpenEx("FT4232H_MM A", FT_OPEN_BY_DESCRIPTION, &fthandle);

			if (status != FT_OK)
			{
				printf("Open status not ok %d\n", status);
				printf("Trying to open unprogrammed EEPROM device...\n");
				status = FT_OpenEx("Quad RS232-HS A", FT_OPEN_BY_DESCRIPTION, &fthandle);
				if (status != FT_OK)
				{
					printf("Open status not ok %d\n", status);
					printf("\n");
					return 0;
				}
				else
				{
					printf("Open status OK %d\n", status);
					printf("\n");
				}

				printf("\n");
			}
			else
			{
				printf("Open status OK %d\n", status);
				printf("\n");
			}


			//********************************************************
			//Read the EEPROM
			//********************************************************

			status = FT_EE_Read(fthandle, &ftData);

			if (status != FT_OK)
			{
				printf("EE_Read status not ok %d\n", status);
				if (status == FT_EEPROM_NOT_PROGRAMMED)
				{
					printf("EEPROM is not programmed! Programming with preset values.\n");

					char ManufacturerBufNew[32] = "FTDI";
					char ManufacturerIdBufNew[16] = "FT";
					char DescriptionBufNew[64] = "FT4232H_MM";
					char SerialNumberBufNew[16] = "FT11111";

					ftData.Manufacturer = ManufacturerBufNew;
					ftData.ManufacturerId = ManufacturerIdBufNew;
					ftData.Description = DescriptionBufNew;
					ftData.SerialNumber = SerialNumberBufNew;

					ftData.MaxPower = 90;
					ftData.PnP = 1;
					ftData.SelfPowered = 0;
					ftData.RemoteWakeup = 0;

					//'FT4232H features require section below
					ftData.PullDownEnable8 = 0;		// non-zero if pull down enabled
					ftData.SerNumEnable8 = 1;		// non-zero if serial number to be used
					ftData.ASlowSlew = 0;			// non-zero if A pins have slow slew
					ftData.ASchmittInput = 0;		// non-zero if A pins are Schmitt input
					ftData.ADriveCurrent = 4;		// valid values are 4mA, 8mA, 12mA, 16mA
					ftData.BSlowSlew = 0;			// non-zero if B pins have slow slew
					ftData.BSchmittInput = 0;		// non-zero if B pins are Schmitt input
					ftData.BDriveCurrent = 4;		// valid values are 4mA, 8mA, 12mA, 16mA
					ftData.CSlowSlew = 0;			// non-zero if C pins have slow slew
					ftData.CSchmittInput = 0;		// non-zero if C pins are Schmitt input
					ftData.CDriveCurrent = 4;		// valid values are 4mA, 8mA, 12mA, 16mA
					ftData.DSlowSlew = 0;			// non-zero if D pins have slow slew
					ftData.DSchmittInput = 0;		// non-zero if D pins are Schmitt input
					ftData.DDriveCurrent = 4;		// valid values are 4mA, 8mA, 12mA, 16mA
					ftData.ARIIsTXDEN = 0;			// non-zero if port A uses RI as RS485 TXDEN
					ftData.BRIIsTXDEN = 0;			// non-zero if port B uses RI as RS485 TXDEN
					ftData.CRIIsTXDEN = 0;			// non-zero if port C uses RI as RS485 TXDEN
					ftData.DRIIsTXDEN = 0;			// non-zero if port D uses RI as RS485 TXDEN
					ftData.AIsVCP8 = 1;				// non-zero if interface is to use VCP drivers
					ftData.BIsVCP8 = 1;				// non-zero if interface is to use VCP drivers
					ftData.CIsVCP8 = 1;				// non-zero if interface is to use VCP drivers
					ftData.DIsVCP8 = 1;				// non-zero if interface is to use VCP drivers

					//********************************************************
					//program a blank EEPROM first.
					//********************************************************

					status = FT_EE_Program(fthandle, &ftData);

					if (status != FT_OK)
					{
						printf("Initial FT_EE_Program not ok %d\n", status);
						printf("\n");
					}
					else
					{
						printf("Initial FT_EE_Program OK!\n");
						printf("\n");
					}
				}
				else
				{
					return 0;
				}
			}
			else
			{
				printf("EEPROM is already programmed! Reading EEPROM.\n");

				printf("Signature1 =  0x%04x\n", ftData.Signature1);
				printf("Signature2 =  0x%04x\n", ftData.Signature2);
				printf("Version =  0x%04x\n", ftData.Version);


				printf("VendorID =  0x%04x\n", ftData.VendorId);
				printf("ProductID =  0x%04x\n", ftData.ProductId);
				printf("Manufacturer =  %s\n", ftData.Manufacturer);
				printf("ManufacturerID =  %s\n", ftData.ManufacturerId);
				printf("Description =  %s\n", ftData.Description);
				printf("SerialNumber =  %s\n", ftData.SerialNumber);
				printf("MaxPower =  %d\n", ftData.MaxPower);
				printf("PnP =  %x\n", ftData.PnP);
				printf("SelfPowered =  %x\n", ftData.SelfPowered);
				printf("RemoteWakeup =  %x\n", ftData.RemoteWakeup);

				printf("PullDownEnable8 =  %x\n", ftData.PullDownEnable8);
				printf("SerNumEnable8 =  %x\n", ftData.SerNumEnable8);
				printf("ASlowSlew =  %x\n", ftData.ASlowSlew);
				printf("ASchmittInput =  %x\n", ftData.ASchmittInput);
				printf("ADriveCurrent =  %x\n", ftData.ADriveCurrent);
				printf("BSlowSlew =  %x\n", ftData.BSlowSlew);
				printf("BSchmittInput =  %x\n", ftData.BSchmittInput);
				printf("BDriveCurrent =  %x\n", ftData.BDriveCurrent);
				printf("CSlowSlew =  %x\n", ftData.CSlowSlew);
				printf("CSchmittInput =  %x\n", ftData.CSchmittInput);
				printf("CDriveCurrent =  %x\n", ftData.CDriveCurrent);
				printf("DSlowSlew =  %x\n", ftData.DSlowSlew);
				printf("DSchmittInput =  %x\n", ftData.DSchmittInput);
				printf("DDriveCurrent =  %x\n", ftData.DDriveCurrent);
				printf("ARIIsTXDEN =  %x\n", ftData.ARIIsTXDEN);
				printf("BRIIsTXDEN =  %x\n", ftData.BRIIsTXDEN);
				printf("CRIIsTXDEN =  %x\n", ftData.CRIIsTXDEN);
				printf("DRIIsTXDEN =  %x\n", ftData.DRIIsTXDEN);
				printf("AIsVCP8 =  %x\n", ftData.AIsVCP8);
				printf("BIsVCP8 =  %x\n", ftData.BIsVCP8);
				printf("CIsVCP8 =  %x\n", ftData.CIsVCP8);
				printf("DIsVCP8 =  %x\n", ftData.DIsVCP8);
				printf("\n");
			}

			//********************************************************
			//change serial number from one that was read.
			//********************************************************

			ftData.SerialNumber = "FT12345";

			status = FT_EE_Program(fthandle, &ftData);

			if (status != FT_OK)
			{
				printf("EE_Program status not ok %d\n", status);
				return 0;
			}
			else
			{
				printf("EE_Program status ok %d\n", status);
				printf("\n");
			}


			//********************************************************
			// Delay
			//********************************************************

			Sleep(1000);

			//********************************************************
			// Re - Read
			//********************************************************


			ftData.SerialNumber = SerialNumberBuf; //Reset to variable

			printf("Reading EEPROM to check changed values!\n");
			printf("\n");

			status = FT_EE_Read(fthandle, &ftData);

			if (status != FT_OK)
			{
				printf("EE_Read status not ok %d\n", status);
				return 0;
			}
			else
			{
				printf("Signature1 =  0x%04x\n", ftData.Signature1);
				printf("Signature2 =  0x%04x\n", ftData.Signature2);
				printf("Version =  0x%04x\n", ftData.Version);


				printf("VendorID =  0x%04x\n", ftData.VendorId);
				printf("ProductID =  0x%04x\n", ftData.ProductId);
				printf("Manufacturer =  %s\n", ftData.Manufacturer);
				printf("ManufacturerID =  %s\n", ftData.ManufacturerId);
				printf("Description =  %s\n", ftData.Description);
				printf("SerialNumber =  %s\n", ftData.SerialNumber);
				printf("MaxPower =  %d\n", ftData.MaxPower);
				printf("PnP =  %x\n", ftData.PnP);
				printf("SelfPowered =  %x\n", ftData.SelfPowered);
				printf("RemoteWakeup =  %x\n", ftData.RemoteWakeup);

				printf("PullDownEnable8 =  %x\n", ftData.PullDownEnable8);
				printf("SerNumEnable8 =  %x\n", ftData.SerNumEnable8);
				printf("ASlowSlew =  %x\n", ftData.ASlowSlew);
				printf("ASchmittInput =  %x\n", ftData.ASchmittInput);
				printf("ADriveCurrent =  %x\n", ftData.ADriveCurrent);
				printf("BSlowSlew =  %x\n", ftData.BSlowSlew);
				printf("BSchmittInput =  %x\n", ftData.BSchmittInput);
				printf("BDriveCurrent =  %x\n", ftData.BDriveCurrent);
				printf("CSlowSlew =  %x\n", ftData.CSlowSlew);
				printf("CSchmittInput =  %x\n", ftData.CSchmittInput);
				printf("CDriveCurrent =  %x\n", ftData.CDriveCurrent);
				printf("DSlowSlew =  %x\n", ftData.DSlowSlew);
				printf("DSchmittInput =  %x\n", ftData.DSchmittInput);
				printf("DDriveCurrent =  %x\n", ftData.DDriveCurrent);
				printf("ARIIsTXDEN =  %x\n", ftData.ARIIsTXDEN);
				printf("BRIIsTXDEN =  %x\n", ftData.BRIIsTXDEN);
				printf("CRIIsTXDEN =  %x\n", ftData.CRIIsTXDEN);
				printf("DRIIsTXDEN =  %x\n", ftData.DRIIsTXDEN);
				printf("AIsVCP8 =  %x\n", ftData.AIsVCP8);
				printf("BIsVCP8 =  %x\n", ftData.BIsVCP8);
				printf("CIsVCP8 =  %x\n", ftData.CIsVCP8);
				printf("DIsVCP8 =  %x\n", ftData.DIsVCP8);
				printf("\n");
			}

			//*****************************************************
			//Close the port
			//*****************************************************

			// Close the device
			status = FT_Close(fthandle);

			//Increment i to avoid opening channel B/C/D of the same device
			i = i + 3; 

		}

	}

	printf("Press Return To End Program");
	getchar();
	printf("closed \n");

	return 0;
}

