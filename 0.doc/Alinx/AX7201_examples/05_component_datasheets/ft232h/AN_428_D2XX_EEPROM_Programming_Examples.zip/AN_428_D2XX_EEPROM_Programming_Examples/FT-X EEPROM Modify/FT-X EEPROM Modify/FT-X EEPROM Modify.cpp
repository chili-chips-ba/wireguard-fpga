// FT-X EEPROM Modify.cpp : Defines the entry point for the console application.
//
// NOTE:	This code is provided as an example only and is not supported or guaranteed by FTDI.
//			It is the responsibility of the recipient/user to ensure the correct operation of 
//			any software which is created based upon this example.

#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include "ftd2xx.h"

int main()
{
	//********************************************************
	//Definitions
	//********************************************************

	FT_HANDLE fthandle;
	FT_STATUS status;

	BOOLEAN Dev_Found = FALSE;
	
	WORD VendorIdBuf = 0x0403;
	WORD ProductIdBuf = 0x6015;
	char Manufacturer[64] = { 0 };
	char ManufacturerId[64] = { 0 };
	char Description[64] = { 0 };
	char SerialNumber[64] = { 0 };

	FT_EEPROM_HEADER ft_eeprom_header;
	ft_eeprom_header.deviceType = FT_DEVICE_X_SERIES;

	ft_eeprom_header.VendorId = VendorIdBuf;
	ft_eeprom_header.ProductId = ProductIdBuf;

	ft_eeprom_header.SerNumEnable = 1;
	ft_eeprom_header.MaxPower = 90;
	ft_eeprom_header.SelfPowered = 0;
	ft_eeprom_header.RemoteWakeup = 0;
	ft_eeprom_header.PullDownEnable = 0;

	FT_EEPROM_X_SERIES ft_eeprom_x_series;
	ft_eeprom_x_series.common = ft_eeprom_header;
	ft_eeprom_x_series.ACSlowSlew;			// non-zero if AC bus pins have slow slew
	ft_eeprom_x_series.ACSchmittInput;		// non-zero if AC bus pins are Schmitt input
	ft_eeprom_x_series.ACDriveCurrent;		// valid values are 4mA, 8mA, 12mA, 16mA
	ft_eeprom_x_series.ADSlowSlew;			// non-zero if AD bus pins have slow slew
	ft_eeprom_x_series.ADSchmittInput;		// non-zero if AD bus pins are Schmitt input
	ft_eeprom_x_series.ADDriveCurrent;		// valid values are 4mA, 8mA, 12mA, 16mA
	ft_eeprom_x_series.Cbus0;				// Cbus Mux control
	ft_eeprom_x_series.Cbus1;				// Cbus Mux control
	ft_eeprom_x_series.Cbus2;				// Cbus Mux control
	ft_eeprom_x_series.Cbus3;				// Cbus Mux control
	ft_eeprom_x_series.Cbus4;				// Cbus Mux control
	ft_eeprom_x_series.Cbus5;				// Cbus Mux control
	ft_eeprom_x_series.Cbus6;				// Cbus Mux control
	ft_eeprom_x_series.InvertTXD;			// non-zero if invert TXD
	ft_eeprom_x_series.InvertRXD;			// non-zero if invert RXD
	ft_eeprom_x_series.InvertRTS;			// non-zero if invert RTS
	ft_eeprom_x_series.InvertCTS;			// non-zero if invert CTS
	ft_eeprom_x_series.InvertDTR;			// non-zero if invert DTR
	ft_eeprom_x_series.InvertDSR;			// non-zero if invert DSR
	ft_eeprom_x_series.InvertDCD;			// non-zero if invert DCD
	ft_eeprom_x_series.InvertRI;			// non-zero if invert RI
	ft_eeprom_x_series.BCDEnable;			// Enable Battery Charger Detection
	ft_eeprom_x_series.BCDForceCbusPWREN;	// asserts the power enable signal on CBUS when charging port detected
	ft_eeprom_x_series.BCDDisableSleep;		// forces the device never to go into sleep mode
	ft_eeprom_x_series.I2CSlaveAddress;		// I2C slave device address
	ft_eeprom_x_series.I2CDeviceId;			// I2C device ID
	ft_eeprom_x_series.I2CDisableSchmitt;	// Disable I2C Schmitt trigger
	ft_eeprom_x_series.FT1248Cpol;			// FT1248 clock polarity - clock idle high (1) or clock idle low (0)
	ft_eeprom_x_series.FT1248Lsb;			// FT1248 data is LSB (1) or MSB (0)
	ft_eeprom_x_series.FT1248FlowControl;	// FT1248 flow control enable
	ft_eeprom_x_series.RS485EchoSuppress;	// 
	ft_eeprom_x_series.PowerSaveEnable;		// 
	ft_eeprom_x_series.DriverType;			// 

	//********************************************************
	//List Devices
	//********************************************************

	FT_DEVICE_LIST_INFO_NODE *devInfo;
	DWORD numDevs;
	DWORD i;

	// create the device information list 
	status = FT_CreateDeviceInfoList(&numDevs);

	if (status != FT_OK) {
		printf("FT_CreateDeviceInfoList status not ok %d\n", status);
		return 0;
	}
	else
	{
		printf("Number of devices is %d\n", numDevs);
		if (numDevs > 0) {
			// allocate storage for list based on numDevs 
			devInfo =
				(FT_DEVICE_LIST_INFO_NODE*)malloc(sizeof(FT_DEVICE_LIST_INFO_NODE)*numDevs);
			// get the device information list 
			status = FT_GetDeviceInfoList(devInfo, &numDevs);
			if (status == FT_OK) {
				for (i = 0; i < numDevs; i++) {
					printf("Dev %d:\n", i);
					printf("Flags=0x%x\n", devInfo[i].Flags);
					printf("Type=0x%x\n", devInfo[i].Type);
					printf("ID=0x%x\n", devInfo[i].ID);
					printf("LocId=0x%x\n", devInfo[i].LocId);
					printf("SerialNumber=%s\n", devInfo[i].SerialNumber);
					printf("Description=%s\n", devInfo[i].Description);
					printf("\n");
				}
			}
		}
	}

	//********************************************************
	//Open the port
	//********************************************************

	for (i = 0; i < numDevs; i++)
	{
		if ((Dev_Found == FALSE) && (devInfo[i].Type == FT_DEVICE_X_SERIES))
		{
			Dev_Found = TRUE;
			
			status = FT_OpenEx("Chipi-X", FT_OPEN_BY_DESCRIPTION, &fthandle);

			if (status != FT_OK)
			{
				printf("Open status not ok %d\n", status);
				printf("Trying to open default EEPROM device...\n");
				status = FT_OpenEx("FT231X USB UART", FT_OPEN_BY_DESCRIPTION, &fthandle);
				if (status != FT_OK)
				{
					printf("Open status not ok %d\n", status);
					printf("\n");
					return 0;
				}
				else
				{
					printf("Open status OK %d\n", status);
					printf("\n");
				}

				printf("\n");
			}
			else
			{
				printf("Open status OK %d\n", status);
				printf("\n");
			}


			//********************************************************
			// Re - Read
			//********************************************************
			status = FT_EEPROM_Read(fthandle, &ft_eeprom_x_series, sizeof(ft_eeprom_x_series), Manufacturer, ManufacturerId, Description, SerialNumber);

			if (status != FT_OK)
			{
				printf("FT_EEPROM_Read status not ok %d\n", status);
				return 0;
			}
			else
			{
				printf("Manufacturer %s\n", Manufacturer);
				printf("ManufacturerId %s\n", ManufacturerId);
				printf("Description %s\n", Description);
				printf("SerialNumber %s\n", SerialNumber);
				printf("deviceType %x\n", ft_eeprom_header.deviceType);
				printf("VendorId %04x\n", ft_eeprom_header.VendorId);
				printf("ProductId %04x\n", ft_eeprom_header.ProductId);
				printf("MaxPower %d\n", ft_eeprom_header.MaxPower);
				printf("SelfPowered %x\n", ft_eeprom_header.SelfPowered);
				printf("RemoteWakeup %x\n", ft_eeprom_header.RemoteWakeup);
				printf("PullDownEnable %x\n", ft_eeprom_header.PullDownEnable);
				printf("ACSlowSlew %x\n", ft_eeprom_x_series.ACSlowSlew);
				printf("ACSchmittInput %x\n", ft_eeprom_x_series.ACSchmittInput);
				printf("ACDriveCurrent %x\n", ft_eeprom_x_series.ACDriveCurrent);
				printf("ADSlowSlew %x\n", ft_eeprom_x_series.ADSlowSlew);
				printf("ADSchmittInput %x\n", ft_eeprom_x_series.ADSchmittInput);
				printf("ADDriveCurrent %x\n", ft_eeprom_x_series.ADDriveCurrent);
				printf("Cbus0 %x\n", ft_eeprom_x_series.Cbus0);
				printf("Cbus1 %x\n", ft_eeprom_x_series.Cbus1);
				printf("Cbus2 %x\n", ft_eeprom_x_series.Cbus2);
				printf("Cbus3 %x\n", ft_eeprom_x_series.Cbus3);
				printf("Cbus4 %x\n", ft_eeprom_x_series.Cbus4);
				printf("Cbus5 %x\n", ft_eeprom_x_series.Cbus5);
				printf("Cbus6 %x\n", ft_eeprom_x_series.Cbus6);
				printf("InvertTXD %x\n", ft_eeprom_x_series.InvertTXD);
				printf("InvertRXD %x\n", ft_eeprom_x_series.InvertRXD);
				printf("InvertRTS %x\n", ft_eeprom_x_series.InvertRTS);
				printf("InvertCTS %x\n", ft_eeprom_x_series.InvertCTS);
				printf("InvertDTR %x\n", ft_eeprom_x_series.InvertDTR);
				printf("InvertDSR %x\n", ft_eeprom_x_series.InvertDSR);
				printf("InvertDCD %x\n", ft_eeprom_x_series.InvertDCD);
				printf("InvertRI %x\n", ft_eeprom_x_series.InvertRI);
				printf("BCDEnable %x\n", ft_eeprom_x_series.BCDEnable);
				printf("BCDForceCbusPWREN %x\n", ft_eeprom_x_series.BCDForceCbusPWREN);
				printf("BCDDisableSleep %x\n", ft_eeprom_x_series.BCDDisableSleep);
				printf("I2CSlaveAddress %x\n", ft_eeprom_x_series.I2CSlaveAddress);
				printf("I2CDeviceId %x\n", ft_eeprom_x_series.I2CDeviceId);
				printf("I2CDisableSchmitt %x\n", ft_eeprom_x_series.I2CDisableSchmitt);
				printf("FT1248Cpol %x\n", ft_eeprom_x_series.FT1248Cpol);
				printf("FT1248Lsb %x\n", ft_eeprom_x_series.FT1248Lsb);
				printf("FT1248FlowControl %x\n", ft_eeprom_x_series.FT1248FlowControl);
				printf("RS485EchoSuppress %x\n", ft_eeprom_x_series.RS485EchoSuppress);
				printf("PowerSaveEnable %x\n", ft_eeprom_x_series.PowerSaveEnable);
				printf("DriverType %x\n", ft_eeprom_x_series.DriverType);
				printf("\n");
			}

			//********************************************************
			// FT_EEPROM_Program
			//********************************************************

			strcpy_s(SerialNumber, "FT12345");

			status = FT_EEPROM_Program(fthandle, &ft_eeprom_x_series, sizeof(ft_eeprom_x_series), Manufacturer, ManufacturerId, Description, SerialNumber);

			if (status != FT_OK)
			{
				printf("FT_EEPROM_Program status not ok %d\n", status);
				return 0;
			}
			else
			{
				printf("FT_EEPROM_Program status ok %d\n", status);
				printf("\n");
			}

			//********************************************************
			// Delay
			//********************************************************

			Sleep(1000);

			//********************************************************
			// Re - Read
			//********************************************************

			status = FT_EEPROM_Read(fthandle, &ft_eeprom_x_series, sizeof(ft_eeprom_x_series), Manufacturer, ManufacturerId, Description, SerialNumber);

			if (status != FT_OK)
			{
				printf("FT_EEPROM_Read status not ok %d\n", status);
				return 0;
			}
			else
			{
				printf("Manufacturer %s\n", Manufacturer);
				printf("ManufacturerId %s\n", ManufacturerId);
				printf("Description %s\n", Description);
				printf("SerialNumber %s\n", SerialNumber);
				printf("deviceType %x\n", ft_eeprom_header.deviceType);
				printf("VendorId %04x\n", ft_eeprom_header.VendorId);
				printf("ProductId %04x\n", ft_eeprom_header.ProductId);
				printf("MaxPower %d\n", ft_eeprom_header.MaxPower);
				printf("SelfPowered %x\n", ft_eeprom_header.SelfPowered);
				printf("RemoteWakeup %x\n", ft_eeprom_header.RemoteWakeup);
				printf("PullDownEnable %x\n", ft_eeprom_header.PullDownEnable);
				printf("ACSlowSlew %x\n", ft_eeprom_x_series.ACSlowSlew);
				printf("ACSchmittInput %x\n", ft_eeprom_x_series.ACSchmittInput);
				printf("ACDriveCurrent %x\n", ft_eeprom_x_series.ACDriveCurrent);
				printf("ADSlowSlew %x\n", ft_eeprom_x_series.ADSlowSlew);
				printf("ADSchmittInput %x\n", ft_eeprom_x_series.ADSchmittInput);
				printf("ADDriveCurrent %x\n", ft_eeprom_x_series.ADDriveCurrent);
				printf("Cbus0 %x\n", ft_eeprom_x_series.Cbus0);
				printf("Cbus1 %x\n", ft_eeprom_x_series.Cbus1);
				printf("Cbus2 %x\n", ft_eeprom_x_series.Cbus2);
				printf("Cbus3 %x\n", ft_eeprom_x_series.Cbus3);
				printf("Cbus4 %x\n", ft_eeprom_x_series.Cbus4);
				printf("Cbus5 %x\n", ft_eeprom_x_series.Cbus5);
				printf("Cbus6 %x\n", ft_eeprom_x_series.Cbus6);
				printf("InvertTXD %x\n", ft_eeprom_x_series.InvertTXD);
				printf("InvertRXD %x\n", ft_eeprom_x_series.InvertRXD);
				printf("InvertRTS %x\n", ft_eeprom_x_series.InvertRTS);
				printf("InvertCTS %x\n", ft_eeprom_x_series.InvertCTS);
				printf("InvertDTR %x\n", ft_eeprom_x_series.InvertDTR);
				printf("InvertDSR %x\n", ft_eeprom_x_series.InvertDSR);
				printf("InvertDCD %x\n", ft_eeprom_x_series.InvertDCD);
				printf("InvertRI %x\n", ft_eeprom_x_series.InvertRI);
				printf("BCDEnable %x\n", ft_eeprom_x_series.BCDEnable);
				printf("BCDForceCbusPWREN %x\n", ft_eeprom_x_series.BCDForceCbusPWREN);
				printf("BCDDisableSleep %x\n", ft_eeprom_x_series.BCDDisableSleep);
				printf("I2CSlaveAddress %x\n", ft_eeprom_x_series.I2CSlaveAddress);
				printf("I2CDeviceId %x\n", ft_eeprom_x_series.I2CDeviceId);
				printf("I2CDisableSchmitt %x\n", ft_eeprom_x_series.I2CDisableSchmitt);
				printf("FT1248Cpol %x\n", ft_eeprom_x_series.FT1248Cpol);
				printf("FT1248Lsb %x\n", ft_eeprom_x_series.FT1248Lsb);
				printf("FT1248FlowControl %x\n", ft_eeprom_x_series.FT1248FlowControl);
				printf("RS485EchoSuppress %x\n", ft_eeprom_x_series.RS485EchoSuppress);
				printf("PowerSaveEnable %x\n", ft_eeprom_x_series.PowerSaveEnable);
				printf("DriverType %x\n", ft_eeprom_x_series.DriverType);
				printf("\n");
			}


			//*****************************************************
			//Close the port
			//*****************************************************

			// Close the device
			status = FT_Close(fthandle);
		}

	}

	printf("Press Return To End Program");
	getchar();
	printf("closed \n");
	
    return 0;
}

