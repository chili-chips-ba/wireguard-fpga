//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by USBtest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_USBTEST_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_SEND128_ECHO         1004
#define IDC_EDIT_ECHO_RESULT            1005
#define IDC_SLIDER_WRITE_RATE           1006
#define IDC_BUTTON_SEND_RECDIS          1012
#define IDC_SPIN1                       1013
#define IDC_EDIT_PORT_SELECTED          1014
#define IDC_EDIT_PORT_STATUS            1015
#define IDC_BUTTON_BLINK_ON             1017
#define IDC_BUTTON_BLINK_OFF            1018
#define IDC_LIST1                       1019
#define IDC_EDIT_NUM_RECD               1021
#define IDC_BUTTON_CLEAR                1023
#define IDC_BUTTON_HELLO                1024
#define IDC_EDIT_128_STATUS             1025
#define IDC_EDIT_NAME_NUMBER            1026
#define IDC_RADIO_NAME_NUM              1027
#define IDC_RADIO_SERNUM                1028
#define IDC_RADIO1                      1029
#define IDC_RADIO_DEVNO                 1029
#define IDC_BUTTON_SEARCH               1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
